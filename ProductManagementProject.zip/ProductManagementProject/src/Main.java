import java.util.Scanner;

import pkg.cogent.controller.ProductController;

public class Main {

	public static void main(String[] args) {
		int choice=0;
		Scanner sc = new Scanner(System.in);
		ProductController pc = new ProductController();
		System.out.println("Welcome to the Product Management Application");
		do {
			sc.reset();
			System.out.println("1-Add product.");
			System.out.println("2-Read all products.");
			System.out.println("3-Read category of products.");
			System.out.println("4-Modify product.");
			System.out.println("5-Delete product by ID.");
			System.out.println("6-Delete products by category.");
			System.out.println("7-Find product by ID.");
			System.out.println("8-List expired products.");
			System.out.println("9-Find cheapest product in category.");
			System.out.println("10-exit");
			System.out.println("Please enter your choice:");
			choice = sc.nextInt();
			pc.accept(choice);
		}while(choice!=10);
		sc.close();

	}

}